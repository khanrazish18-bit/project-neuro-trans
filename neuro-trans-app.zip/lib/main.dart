import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart'; // forAdvertisements

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const NeuroTransApp());
}

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class NeuroTransApp extends StatelessWidget {
  const NeuroTransApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'Neuro Trans',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFFFF5F5),
      ),
      initialRoute: WelcomePageWidget.routePath,
      routes: <String, WidgetBuilder>{
        WelcomePageWidget.routePath: (context) => const WelcomePageWidget(),
        HomePageWidget.routePath: (context) => const HomePageWidget(),
        TranslationPageWidget.routePath: (context) =>
            const TranslationPageWidget(),
        WordMeaningPageWidget.routePath: (context) =>
            const WordMeaningPageWidget(),
        HistoryPageWidget.routePath: (context) => const HistoryPageWidget(),
      },
    );
  }
}

Future<bool> _checkInternetLock(BuildContext context) async {
  var connectivityResult = await (Connectivity().checkConnectivity());
  if (connectivityResult.contains(ConnectivityResult.none)) {
    if (context.mounted) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('انٹرنیٹ ضروری ہے'),
          content: const Text(
              'کیمرہ، وائس، اور پریمیم ٹولز کو استعمال کرنے کے لیے براہ کرم اپنا موبائل ڈیٹا یا وائی فائی آن کریں۔'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('ٹھیک ہے'),
            ),
          ],
        ),
      );
    }
    return false;
  }
  return true;
}

// ⏱️ اشتہارات کی ٹائمنگ سیٹ کرنے کا سمارٹ فنکشن
Future<bool> _isAdAllowed() async {
  final prefs = await SharedPreferences.getInstance();
  final int? installTimestamp = prefs.getInt('install_time');
  final int currentTimestamp = DateTime.now().millisecondsSinceEpoch;

  if (installTimestamp == null) {
    await prefs.setInt('install_time', currentTimestamp);
    return false;
  }
  if (currentTimestamp - installTimestamp > 3600000) {
    return true;
  }
  return false;
}

// ==========================================
// 1. WELCOME PAGE WIDGET
// ==========================================
class WelcomePageWidget extends StatelessWidget {
  static const String routePath = '/';
  const WelcomePageWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const Icon(Icons.psychology_rounded,
                  size: 100, color: Colors.white),
              const SizedBox(height: 24),
              const Text('Neuro Trans',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              const Spacer(),
              ElevatedButton(
                onPressed: () => Navigator.pushReplacementNamed(
                    context, HomePageWidget.routePath),
                child: const Text('Get Started'),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// 2. HOME PAGE WIDGET (BANNER AD INCLUDED)
// ==========================================
class HomePageWidget extends StatefulWidget {
  static const String routePath = '/homePage';
  const HomePageWidget({super.key});

  @override
  State<HomePageWidget> createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  final ImagePicker _picker = ImagePicker();
  late stt.SpeechToText _speech;
  bool _isListening = false;

  BannerAd? _bannerAd;
  bool _isBannerAdLoaded = false;
  InterstitialAd? _interstitialAd;

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _requestAppPermissions();
    _initAds();
  }

  void _initAds() async {
    bool allowAds = await _isAdAllowed();
    if (!allowAds) return;

    _loadBannerAd();
    _loadInterstitialAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111',
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, err) => ad.dispose(),
      ),
    )..load();
  }

  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-3940256099942544/1033173712',
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitialAd = ad,
        onAdFailedToLoad: (err) => _interstitialAd = null,
      ),
    );
  }

  void _showFullAd() {
    if (_interstitialAd != null) {
      _interstitialAd!.show();
      _loadInterstitialAd();
    }
  }

  Future<void> _requestAppPermissions() async {
    await [Permission.camera, Permission.microphone].request();
  }

  // 🌐 کیمرہ اسکین بٹن پر انٹرنیٹ لاک ہے
  Future<void> _processImage(ImageSource source) async {
    bool isOnline = await _checkInternetLock(context);
    if (!isOnline) return;

    _showFullAd();

    final XFile? image = await _picker.pickImage(source: source);
    if (image == null) return;

    final inputImage = InputImage.fromFilePath(image.path);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);

    try {
      final RecognizedText recognizedText =
          await textRecognizer.processImage(inputImage);
      if (mounted) {
        Navigator.pushNamed(context, TranslationPageWidget.routePath,
            arguments: recognizedText.text);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Failed: $e')));
      }
    } finally {
      textRecognizer.close();
    }
  }

  String message = "Voice button is locked. Please turn on internet.";
  Future<void> _listenVoice() async {
    bool isOnline = await _checkInternetLock(context);
    if (!isOnline) return;

    _showFullAd();

    if (!_isListening) {
      bool available = await _speech.initialize();
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(onResult: (val) {
          if (val.finalResult) {
            setState(() => _isListening = false);
            Navigator.pushNamed(context, TranslationPageWidget.routePath,
                arguments: val.recognizedWords);
          }
        });
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF5F5),
      appBar: AppBar(
        backgroundColor: Colors.deepPurple,
        title: const Text('Neuro Trans Home',
            style: TextStyle(color: Colors.white)),
        actions: [
          IconButton(
            icon: const Icon(Icons.history_rounded, color: Colors.white),
            onPressed: () => Navigator.pushNamed(
                context,
                HistoryPageWidget
                    .routePath), // ہسٹری پیج اب آف لائن کھل سکتا ہے
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Translation & Scanner',
                        style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepPurple)),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                            child: ElevatedButton.icon(
                                icon: const Icon(Icons.camera_alt_rounded),
                                label: const Text('Camera'),
                                onPressed: () =>
                                    _processImage(ImageSource.camera))),
                        const SizedBox(width: 12),
                        Expanded(
                            child: ElevatedButton.icon(
                                icon: const Icon(Icons.photo_library_rounded),
                                label: const Text('Gallery'),
                                onPressed: () =>
                                    _processImage(ImageSource.gallery))),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                        icon: Icon(_isListening
                            ? Icons.mic_off_rounded
                            : Icons.mic_rounded),
                        label:
                            Text(_isListening ? 'Listening...' : 'Voice Input'),
                        onPressed: _listenVoice),
                    const SizedBox(height: 24),
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.translate_rounded,
                            color: Colors.deepPurple),
                        title: const Text('Direct Keyboard Translator'),
                        subtitle:
                            const Text('Type to translate text (100% Offline)'),
                        onTap: () => Navigator.pushNamed(
                            context, TranslationPageWidget.routePath,
                            arguments: ''),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: ListTile(
                        leading: const Icon(Icons.menu_book_rounded,
                            color: Colors.deepPurple),
                        title: const Text('Offline Dictionary'),
                        subtitle:
                            const Text('Search word meanings (100% Offline)'),
                        onTap: () => Navigator.pushNamed(
                            context, WordMeaningPageWidget.routePath),
                      ),
                    ),
                  ],
                ),
              ),
            ),
// 💰 ہوم پیج پر نیچے چھوٹا مستقل اشتہار (بغیر صارف کو تنگ کیے کمائی)
            if (_isBannerAdLoaded && _bannerAd != null)
              Container(
                alignment: Alignment.center,
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 3. TRANSLATION PAGE WIDGET (HYBRID OFFLINE TYPING)
// ==========================================
class TranslationPageWidget extends StatefulWidget {
  static const String routePath = '/translationPage';
  const TranslationPageWidget({super.key});
  @override
  State createState() => _TranslationPageWidgetState();
}

class _TranslationPageWidgetState extends State {
  final TextEditingController _inputController = TextEditingController();
  final FlutterTts _flutterTts = FlutterTts();
  final Map<String, TranslateLanguage> _mKitLanguages = {
    'English': TranslateLanguage.english,
    'Urdu': TranslateLanguage.urdu
  };
  String _sourceLangKey = 'English';
  String _targetLangKey = 'Urdu';
  String _translatedText = '';
  bool _isLoading = false;
  late OnDeviceTranslator _translator;
  InterstitialAd? _actionAd;
  @override
  void initState() {
    super.initState();
    _initTranslator();
    _loadActionAd();
  }

  void _initTranslator() {
    _translator = OnDeviceTranslator(
        sourceLanguage: _mKitLanguages[_sourceLangKey]!,
        targetLanguage: _mKitLanguages[_targetLangKey]!);
  }

  void _loadActionAd() async {
    bool allowAds = await _isAdAllowed();
    if (!allowAds) return;
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-3940256099942544/1033173712',
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _actionAd = ad,
        onAdFailedToLoad: (err) => _actionAd = null,
      ),
    );
  }

// 📴 ہاتھ سے ٹائپ کر کے ترجمہ کرنا 100% آف لائن کام کرے گا
  Future _translateText(String text) async {
    if (text.trim().isEmpty) return;
    setState(() => _isLoading = true);
    try {
      await _translator.close();
      _initTranslator();
      final String result = await _translator.translateText(text);
      setState(() => _translatedText = result);
      await _saveToHistory(text, result);
    } catch (e) {
      setState(() => _translatedText = '[Error]: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future _saveToHistory(String source, String target) async {
    void _saveToHistory(String source, String target) async {
      final prefs = await SharedPreferences.getInstance();
      final List<String> history = prefs.getStringList('history_key') ?? [];
      Map<String, String> newItem = {
        'source': source,
        'target': target,
        'date': DateTime.now().toString().substring(0, 10)
      };
      history.insert(0, jsonEncode(newItem));
      await prefs.setStringList('history_key', history);
    }
  }

// 🌐 پی ڈی ایف، شیئر اور کاپی پر انٹرنیٹ لاک اور اشتہارات آن ہیں
  Future _exportPdf() async {
    bool isOnline = await _checkInternetLock(context);
    if (!isOnline) return;
    _loadActionAd();
    if (_actionAd != null) {
      _actionAd!.show();
    }
    if (_translatedText.isEmpty) return;
    final pw.Document pdf = pw.Document();
    final fontData = await rootBundle.load("assets/fonts/NotoSans-Regular.ttf");
    final ttfFont = pw.Font.ttf(fontData);
    pdf.addPage(pw.Page(
        build: (pw.Context context) => pw.Column(children: [
              pw.Text(_translatedText, style: pw.TextStyle(font: ttfFont))
            ])));
    final Directory output = await getTemporaryDirectory();
    final File file = File('${output.path}/translation.pdf');
    await file.writeAsBytes(await pdf.save());
    await Share.shareXFiles([XFile(file.path)]);
  }

  Future _shareOrCopy(String type) async {
    bool isOnline = await _checkInternetLock(context);
    if (!isOnline) return;
    _actionAd?.show();
    _loadActionAd();
    if (_translatedText.isEmpty) return;
    if (type == 'share') {
      await Share.share(_translatedText);
    } else {
      await Clipboard.setData(ClipboardData(text: _translatedText));
    }
  }

  @override
  void dispose() {
    _translator.close();
    _flutterTts.stop();
    _inputController.dispose();
    _actionAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Translator'),
        actions: [
          PopupMenuButton(
            onSelected: (val) {
              if (val == 'pdf') _exportPdf();
              if (val == 'share') _shareOrCopy('share');
              if (val == 'copy') _shareOrCopy('copy');
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                  value: 'pdf', child: Text('Export PDF (Online)')),
              const PopupMenuItem(
                  value: 'share', child: Text('Share Text (Online)')),
              const PopupMenuItem(
                  value: 'copy', child: Text('Copy Text (Online)')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        TextField(controller: _inputController),
        ElevatedButton(
            onPressed: () => _translateText(_inputController.text),
            child: const Text('Translate')),
        Text(_translatedText)
      ]),
    );
  }
}

// ==========================================
// 4. OFFLINE DICTIONARY WIDGET (100% FREE OFFLINE)
// ==========================================
class WordMeaningPageWidget extends StatefulWidget {
  static const String routePath = '/wordMeaningPage';
  const WordMeaningPageWidget({super.key});
  @override
  State createState() => _WordMeaningPageWidgetState();
}

class _WordMeaningPageWidgetState extends State {
  final TextEditingController _wordController = TextEditingController();
  String _definition = '';
  void _lookupMeaning(String word) {
    if (word.trim().isEmpty) return;
    setState(() {
      _definition = 'Offline Meaning for "$word" loaded instantly.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(children: [
      TextField(controller: _wordController, onSubmitted: _lookupMeaning),
      Text(_definition)
    ]));
  }
}

// ==========================================
// 5. HISTORY PAGE WIDGET (FREE OFFLINE VIEW)
// ==========================================
class HistoryPageWidget extends StatefulWidget {
  static const String routePath = '/historyPage';
  const HistoryPageWidget({super.key});
  @override
  State createState() => _HistoryPageWidgetState();
}

class _HistoryPageWidgetState extends State {
  BannerAd? _bannerAd;
  bool _isBannerAdLoaded = false;
  List<Map<String, dynamic>> _historyList = [];
  late stt.SpeechToText _speech;
  dynamic _interstitialAd;
  dynamic _picker;
  bool _isListening = false;
  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final List cachedHistory = prefs.getStringList('history_key') ?? [];
    setState(() {
      _historyList = cachedHistory
          .map((item) => jsonDecode(item) as Map<String, dynamic>)
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: const Text('Translation History Logs')),
        body: ListView.builder(
            itemCount: _historyList.length,
            itemBuilder: (context, index) {
              final item = _historyList[index];
              return ListTile(
                  title: Text(item['source'] ?? ''),
                  subtitle: Text(item['target'] ?? ''));
            }));
  }

  void _initAds() async {
    bool allowAds = await _isAdAllowed();
    if (!allowAds) return;

    _loadBannerAd();
    _loadInterstitialAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-3940256099942544/6300978111',
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (ad) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, err) => ad.dispose(),
      ),
    )..load();
  }

  void _loadInterstitialAd() {
    InterstitialAd.load(
      adUnitId: 'ca-app-pub-3940256099942544/1033173712',
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitialAd = ad,
        onAdFailedToLoad: (err) => _interstitialAd = null,
      ),
    );
  }

  void _showFullAd() {
    if (_interstitialAd != null) {
      _interstitialAd!.show();
      _loadInterstitialAd();
    }
  }

  Future<void> _requestAppPermissions() async {
    await [Permission.camera, Permission.microphone].request();
  }

// 🌐 کیمرہ اسکین بٹن پر انٹرنیٹ لاک ہے
  Future<void> _processImage(ImageSource source) async {
    bool isOnline = await _checkInternetLock(context);
    if (!isOnline) return;

    _showFullAd();

    final XFile? image = await _picker.pickImage(source: source);
    if (image == null) return;

    final inputImage = InputImage.fromFilePath(image.path);
    final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);

    try {
      final RecognizedText recognizedText =
          await textRecognizer.processImage(inputImage);
      if (mounted) {
        Navigator.pushNamed(context, TranslationPageWidget.routePath,
            arguments: recognizedText.text);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Failed: $e')));
      }
    } finally {
      textRecognizer.close();
    }
  }

// 🌐 وائس بٹن پر انٹرنیٹ لاک ہے
  Future<void> _listenVoice() async {
    bool isOnline = await _checkInternetLock(context);
    if (!isOnline) return;

    _showFullAd();

    if (!_isListening) {
      bool available = await _speech.initialize();
      if (available) {
        setState(() => _isListening = true);
        _speech.listen(onResult: (val) {
          if (val.finalResult) {
            setState(() => _isListening = false);
            Navigator.pushNamed(context, TranslationPageWidget.routePath,
                arguments: val.recognizedWords);
          }
        });
      }
    } else {
      setState(() => _isListening = false);
      _speech.stop();
    }
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    _interstitialAd?.dispose();
    super.dispose();
  }
}
