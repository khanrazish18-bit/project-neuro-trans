package com.example.neurotransapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
